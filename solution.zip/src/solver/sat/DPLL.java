package solver.sat;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class DPLL {
  public static boolean solveSAT(SATInstance instance) {
    // initialize assignments map with no assignments
    Map<Integer, Boolean> assignments = new HashMap<>();
    return dpll(instance, assignments);
  }

  private static boolean dpll(SATInstance instance, Map<Integer, Boolean> assignments) {
    // base case: if all clauses are satisfied, return true
    if (allClausesSatisfied(instance, assignments)) {
      return true;
    }

    // base case: if some clause is not satisfied, return false
    if (someClauseUnsatisfied(instance, assignments)) {
      return false;
    }

    // choose an unassigned variable
    Integer variable = chooseVariable(instance, assignments);
    if (variable == null) {
      return false; // No variables left to assign, but not all clauses are satisfied
    }

    // try assigning true to the variable
    Map<Integer, Boolean> assignmentsWithTrue = new HashMap<>(assignments);
    assignmentsWithTrue.put(variable, true);
    if (dpll(instance, assignmentsWithTrue)) {
      return true;
    }

    // try assigning false to the variable
    Map<Integer, Boolean> assignmentsWithFalse = new HashMap<>(assignments);
    assignmentsWithFalse.put(variable, false);
    return dpll(instance, assignmentsWithFalse);
  }

  private static boolean allClausesSatisfied(SATInstance instance, Map<Integer, Boolean> assignments) {
    for (Set<Integer> clause : instance.clauses) {
      boolean clauseSatisfied = false;
      for (Integer literal : clause) {
        int var = Math.abs(literal);
        boolean val = literal > 0;
        if (assignments.containsKey(var) && assignments.get(var) == val) {
          clauseSatisfied = true;
          break;
        }
      }
      if (!clauseSatisfied) {
        return false;
      }
    }
    return true;
  }

  private static boolean someClauseUnsatisfied(SATInstance instance, Map<Integer, Boolean> assignments) {
    for (Set<Integer> clause : instance.clauses) {
      boolean clauseUnsatisfied = true;
      for (Integer literal : clause) {
        int var = Math.abs(literal);
        boolean val = literal > 0;
        if (!assignments.containsKey(var) || assignments.get(var) == val) {
          clauseUnsatisfied = false;
          break;
        }
      }
      if (clauseUnsatisfied) {
        return true;
      }
    }
    return false;
  }

  private static Integer chooseVariable(SATInstance instance, Map<Integer, Boolean> assignments) {
    for (Integer var : instance.vars) {
      if (!assignments.containsKey(var)) {
        return var;
      }
    }
    return null;
  }

  private DPLL(){}
}
